// lib.jsx — shared hooks + atoms. Exports to window for cross-file sharing.

const { useState, useEffect, useRef, useMemo, useCallback, useLayoutEffect } = React;

/* ---------- Hooks ---------- */

function useInView(opts = {}) {
  const ref = useRef(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    if (!ref.current || seen) return;
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setSeen(true); io.disconnect(); }
    }, { threshold: 0.15, ...opts });
    io.observe(ref.current);
    return () => io.disconnect();
  }, [seen]);
  return [ref, seen];
}

function useScrollProgress(ref) {
  const [p, setP] = useState(0);
  useEffect(() => {
    if (!ref.current) return;
    let raf = 0;
    const tick = () => {
      raf = 0;
      const el = ref.current; if (!el) return;
      const r = el.getBoundingClientRect();
      const vh = window.innerHeight;
      const total = r.height - vh;
      const t = Math.min(1, Math.max(0, -r.top / total));
      setP(t);
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(tick); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [ref]);
  return p;
}

function useCountUp(target, { duration = 1400, decimals = 0, motion = 1 } = {}) {
  const [ref, seen] = useInView();
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!seen) return;
    if (motion <= 0) { setVal(target); return; }
    const dur = duration / Math.max(0.2, motion);
    const start = performance.now();
    let raf;
    const tick = (now) => {
      const t = Math.min(1, (now - start) / dur);
      const eased = 1 - Math.pow(1 - t, 3);
      setVal(target * eased);
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => raf && cancelAnimationFrame(raf);
  }, [seen, target, duration, motion]);
  const display = useMemo(() => {
    const n = Number(val.toFixed(decimals));
    return decimals > 0 ? n.toFixed(decimals) : Math.round(n).toLocaleString();
  }, [val, decimals]);
  return [ref, display, seen];
}

/* Format helpers */
const fmtUsd = (n) => {
  if (n >= 1e9) return `$${(n/1e9).toFixed(1)}B`;
  if (n >= 1e6) return `$${(n/1e6).toFixed(1)}M`;
  if (n >= 1e3) return `$${(n/1e3).toFixed(1)}K`;
  return `$${n}`;
};
const fmtNum = (n) => n.toLocaleString();
const fmtPct = (n, d=1) => `${n>0?'+':''}${n.toFixed(d)}%`;

/* ---------- Atoms ---------- */

function Kicker({ children }) {
  return <span className="kicker">{children}</span>;
}

function Meta({ children }) {
  return <span className="meta">{children}</span>;
}

function Chip({ children, kind, ...rest }) {
  return <span className={`chip${kind ? ' '+kind : ''}`} {...rest}>{children}</span>;
}

function Counter({ value, prefix = '', suffix = '', decimals = 0, motion = 1 }) {
  const [ref, display] = useCountUp(value, { decimals, motion });
  return <span ref={ref} className="count tnum">{prefix}{display}{suffix}</span>;
}

function Reveal({ as = 'div', mode, delay = 0, children, className = '', style, ...rest }) {
  const Tag = as;
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { ref.current.classList.add('in'); io.disconnect(); }
    }, { threshold: 0.18 });
    io.observe(ref.current);
    return () => io.disconnect();
  }, []);
  return (
    <Tag
      ref={ref}
      data-reveal={mode || true}
      style={{ ...(style||{}), '--reveal-delay': delay }}
      className={className}
      {...rest}
    >{children}</Tag>
  );
}

function SectionTag({ n, title, source }) {
  return (
    <div className="section-tag">
      <span className="num">§ {n}</span>
      <span className="ttl">{title}</span>
      <span style={{ flex: 1 }}></span>
      {source && <span>Source / {source}</span>}
    </div>
  );
}

/* Slot — labeled placeholder for content user will swap in */
function Slot({ kind = 'video', label, source, url, aspect = '16/9', children, height, style }) {
  return (
    <div className={`slot ${kind}`} style={{ aspectRatio: !height ? aspect : undefined, height, ...style }}>
      {children}
      <div className="slot-meta">
        <span className="badge">●</span>
        <span>{kind === 'video' ? 'YouTube' : kind === 'article' ? 'Article' : kind === 'image' ? 'Image' : kind}</span>
        <span style={{ color: 'var(--ink-low)' }}>/</span>
        <span style={{ color: 'var(--ink)' }}>{label || 'Paste embed / link here'}</span>
        {source && <span style={{ color: 'var(--ink-low)' }}>· {source}</span>}
        {url && <span style={{ color: 'var(--ink-low)' }}>· {url}</span>}
      </div>
    </div>
  );
}

/* KPI block */
function Kpi({ label, value, suffix = '', prefix = '', delta, sub, decimals = 0, motion = 1 }) {
  return (
    <div className="kpi">
      <div className="lbl">{label}</div>
      <div className="val">
        <Counter value={value} prefix={prefix} suffix={suffix} decimals={decimals} motion={motion} />
      </div>
      {(sub || delta != null) && (
        <div className="sub">
          {delta != null && (
            <span className={`delta ${delta >= 0 ? 'pos' : 'neg'}`}>
              {delta >= 0 ? '▲' : '▼'} {Math.abs(delta).toFixed(1)}%
            </span>
          )}{delta != null && sub && ' · '}
          {sub}
        </div>
      )}
    </div>
  );
}

/* Glossary tooltip */
function Gloss({ term, def, children }) {
  return (
    <span className="gloss">
      {children || term}
      <span className="gloss-pop">
        <span style={{ display: 'block', fontFamily: 'var(--f-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '.14em', color: 'var(--accent-soft)', marginBottom: 4 }}>{term}</span>
        {def}
      </span>
    </span>
  );
}

/* Pull quote */
function Pull({ children, attrib }) {
  return (
    <Reveal className="pull" style={{ borderLeft: '3px solid var(--accent)', padding: '8px 0 8px 22px', margin: '24px 0' }}>
      <div className="serif" style={{ fontSize: 28, lineHeight: 1.25, letterSpacing: '-0.015em' }}>
        “{children}”
      </div>
      {attrib && <div className="meta" style={{ marginTop: 12 }}>— {attrib}</div>}
    </Reveal>
  );
}

/* Marquee ticker */
function Marquee({ items }) {
  const content = items.map((it, i) => (
    <span key={i} style={{ display: 'inline-flex', gap: 12, alignItems: 'baseline' }}>
      <span style={{ color: 'var(--ink-low)' }}>●</span>
      <span style={{ color: 'var(--ink)' }}>{it.label}</span>
      <span className="numeral" style={{ color: 'var(--ink-mid)' }}>{it.value}</span>
      {it.delta != null && (
        <span style={{ color: it.delta >= 0 ? 'var(--pos)' : 'var(--neg)' }}>
          {it.delta >= 0 ? '▲' : '▼'} {Math.abs(it.delta).toFixed(1)}%
        </span>
      )}
    </span>
  ));
  return (
    <div className="marquee">
      <div className="marquee-track">
        {content}{content}
      </div>
    </div>
  );
}

/* Sticky page index */
function TableOfContents({ sections, active }) {
  return (
    <nav className="toc">
      {sections.map((s, i) => (
        <a key={s.id} href={`#${s.id}`} className={active === i ? 'active' : ''}>
          <span className="n">0{i+1}</span>
          <span className="bar"></span>
          <span>{s.label}</span>
        </a>
      ))}
    </nav>
  );
}

/* ---------- VideoReel: horizontal video carousel with snap ---------- */
function VideoReel({ title, sub, items, cardWidth }) {
  const trackRef = useRef(null);
  const [pos, setPos] = useState({ scrollLeft: 0, scrollWidth: 1, clientWidth: 1 });
  const recompute = useCallback(() => {
    const el = trackRef.current; if (!el) return;
    setPos({ scrollLeft: el.scrollLeft, scrollWidth: el.scrollWidth, clientWidth: el.clientWidth });
  }, []);
  useEffect(() => {
    const el = trackRef.current; if (!el) return;
    recompute();
    el.addEventListener('scroll', recompute, { passive: true });
    window.addEventListener('resize', recompute);
    return () => {
      el.removeEventListener('scroll', recompute);
      window.removeEventListener('resize', recompute);
    };
  }, [recompute]);
  const scrollBy = (dir) => {
    const el = trackRef.current; if (!el) return;
    const step = el.clientWidth * 0.82;
    el.scrollBy({ left: dir * step, behavior: 'smooth' });
  };
  const atStart = pos.scrollLeft <= 4;
  const atEnd   = pos.scrollLeft + pos.clientWidth >= pos.scrollWidth - 4;
  const progPct = pos.scrollWidth > pos.clientWidth
    ? (pos.scrollLeft / (pos.scrollWidth - pos.clientWidth)) * 100
    : 0;
  const windowPct = pos.scrollWidth > 0 ? (pos.clientWidth / pos.scrollWidth) * 100 : 100;

  return (
    <div className="reel">
      <div className="reel-hd">
        <span className="ttl">{title || `${items.length} videos`}</span>
        <span style={{ flex: 1 }}></span>
        {sub && <span className="sub">{sub}</span>}
        <span className="sub" style={{ color: 'var(--accent)' }}>swipe / drag →</span>
        <div className="reel-nav">
          <button className="reel-btn" onClick={() => scrollBy(-1)} disabled={atStart} aria-label="prev">←</button>
          <button className="reel-btn" onClick={() => scrollBy(1)} disabled={atEnd} aria-label="next">→</button>
        </div>
      </div>
      <div ref={trackRef} className="reel-track">
        {items.map((v, i) => (
          <div key={i} className="reel-card" style={cardWidth ? { flexBasis: cardWidth } : undefined}>
            <Slot kind={v.kind || 'video'} label={v.label} source={v.source} aspect={v.aspect || '16/9'}/>
            <div className="reel-cap">
              <span className="idx tnum">{String(i+1).padStart(2, '0')}/{String(items.length).padStart(2, '0')}</span>
              <span style={{ color: 'var(--ink)' }}>{v.title || v.label}</span>
              {v.note && <span className="src">{v.note}</span>}
            </div>
          </div>
        ))}
      </div>
      <div className="reel-progress">
        <span style={{ left: `${progPct * (100 - windowPct) / 100}%`, width: `${windowPct}%` }}></span>
      </div>
    </div>
  );
}

Object.assign(window, {
  useInView, useScrollProgress, useCountUp,
  fmtUsd, fmtNum, fmtPct,
  Kicker, Meta, Chip, Counter, Reveal,
  SectionTag, Slot, Kpi, Gloss, Pull, Marquee, TableOfContents, VideoReel,
});
