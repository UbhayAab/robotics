// sections-1.jsx — sections 01-06 (Hook, Why Now, Consumer, Manufacturing, Humanoids, Non-humanoid)

const { useState: useS1, useEffect: useE1, useRef: useR1, useMemo: useM1 } = React;

/* ============================================================
   SECTION 01 — HOOK
   ============================================================ */
function S01_Hook({ motion }) {
  const stageRef = useR1(null);
  const [scroll, setScroll] = useS1(0);
  useE1(() => {
    const onScroll = () => setScroll(window.scrollY);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  const parallax = scroll * 0.25 * motion;

  return (
    <section id="hook" data-section="01" data-screen-label="01 Hook" style={{ minHeight: '100vh', position: 'relative', padding: '90px 0 80px', overflow: 'hidden' }}>
      {/* Background grid of dots */}
      <DotField motion={motion} />

      <div className="page" style={{ position: 'relative', zIndex: 2 }}>
        <Reveal style={{ display: 'flex', gap: 14, alignItems: 'baseline', marginBottom: 36 }}>
          <Kicker>Field Notes / Vol. 01</Kicker>
          <span className="meta">May 2026 · Working Draft · v0.3</span>
        </Reveal>

        <h1 className="h-hero" style={{ marginBottom: 28, transform: `translateY(${-parallax * 0.3}px)` }}>
          <Reveal mode="fade" delay={100}>The next</Reveal><br/>
          <Reveal delay={250} style={{ display: 'inline-block' }}>
            platform
          </Reveal>{' '}
          <Reveal delay={400} style={{ display: 'inline-block' }}>
            <span style={{ color: 'var(--accent)', fontStyle: 'italic' }}>has hands.</span>
          </Reveal>
        </h1>

        <div className="col-12" style={{ marginTop: 40 }}>
          <Reveal delay={600} style={{ gridColumn: '1 / span 7' }}>
            <p className="lead">
              A field guide for operators and founders thinking about entering robotics in 2026.
              Compiled from primary sources, public filings, founder interviews, lab demos, and a
              year of obsessive reading. Built to be argued with.
            </p>
          </Reveal>
          <Reveal delay={800} style={{ gridColumn: '9 / span 4', alignSelf: 'end' }}>
            <div className="stack-s" style={{ borderLeft: '1px solid var(--rule)', paddingLeft: 18 }}>
              <span className="meta">Reading time</span>
              <span className="serif" style={{ fontSize: 32, lineHeight: 1 }}>~42 min</span>
              <span className="meta dim">13 chapters · 18 charts · 24 embeds</span>
            </div>
          </Reveal>
        </div>

        <div style={{ height: 90 }}></div>

        {/* Big stat strip */}
        <Reveal delay={400}>
          <div className="stat-strip" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 0, borderTop: '1px solid var(--rule)', borderBottom: '1px solid var(--rule)' }}>
            <BigStat n={1} label="Humanoid pre-orders, 2025" value={32} suffix="K" decimals={0} motion={motion} sub="up from ~600 in 2023"/>
            <BigStat n={2} label="Industrial robot density / 10k workers, S. Korea" value={1012} motion={motion} sub="global leader · IFR 2024"/>
            <BigStat n={3} label="Robotics venture funding, 2024" value={6.4} suffix="B" prefix="$" decimals={1} motion={motion} sub="across 412 disclosed rounds"/>
            <BigStat n={4} label="Cost of a 6-DOF arm, 2015 → 2025" value={-78} suffix="%" motion={motion} sub="median COGS, sub-10kg payload"/>
          </div>
        </Reveal>

        <div style={{ height: 70 }}></div>

        <div className="row" style={{ justifyContent: 'space-between' }}>
          <Reveal>
            <span className="scroll-cue"><span>Scroll to read</span><span className="line"></span></span>
          </Reveal>
          <Reveal delay={200}>
            <span className="meta">13 chapters · ~42 min · last updated 2026-05-17</span>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function BigStat({ n, label, value, prefix = '', suffix = '', decimals = 0, sub, motion }) {
  return (
    <div style={{ padding: '28px 24px', borderRight: n < 4 ? '1px solid var(--rule)' : 'none' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 18 }}>
        <span className="meta">0{n}</span>
        <span className="meta" style={{ color: 'var(--accent)' }}>●</span>
      </div>
      <div className="serif tnum bigstat-val" style={{ fontSize: 52, lineHeight: 1, letterSpacing: '-0.025em', marginBottom: 14 }}>
        <Counter value={value} prefix={prefix} suffix={suffix} decimals={decimals} motion={motion}/>
      </div>
      <div className="meta" style={{ marginBottom: 6, color: 'var(--ink)' }}>{label}</div>
      {sub && <div style={{ fontSize: 12, color: 'var(--ink-low)', fontFamily: 'var(--f-mono)' }}>{sub}</div>}
    </div>
  );
}

function DotField({ motion }) {
  // Animated dot field background — uses CSS only, very cheap
  return (
    <div aria-hidden style={{
      position: 'absolute', inset: 0,
      backgroundImage: 'radial-gradient(var(--ink-fade) 1px, transparent 1px)',
      backgroundSize: '36px 36px',
      maskImage: 'radial-gradient(ellipse at 70% 40%, black 0%, transparent 70%)',
      WebkitMaskImage: 'radial-gradient(ellipse at 70% 40%, black 0%, transparent 70%)',
      opacity: 0.35,
      animation: motion > 0 ? `drift ${30/Math.max(0.2,motion)}s linear infinite` : 'none'
    }}>
      <style>{`@keyframes drift { from { background-position: 0 0; } to { background-position: 36px 36px; } }`}</style>
    </div>
  );
}

/* ============================================================
   SECTION 02 — WHY NOW (horizontal scroll-pinned)
   ============================================================ */
const TAILWINDS = [
  { n: '01', tag: 'CAPABILITY', title: 'Foundation models can finally talk to motors.',
    body: 'Transformer-based VLAs (vision-language-action models) closed the perception-to-action loop that hand-engineered stacks fought for two decades. A single network now ingests language instructions, video frames, and proprioception — and emits joint torques.',
    proof: [
      { k: 'RT-2 → π0 → GR00T', v: '2023–2025' },
      { k: 'Generalist demos', v: '8× yoy' },
      { k: 'Tele-op data, public', v: '~2.4M hrs' }
    ],
    chart: 'capability' },
  { n: '02', tag: 'HARDWARE', title: 'The bill of materials is collapsing.',
    body: 'Cycloidal reducers, harmonic drives, IMUs, LiDAR, BLDC motors — every line item is a fraction of its 2015 price. Chinese supply chains pulled actuator costs down a textbook learning curve; battery energy density nearly doubled.',
    proof: [
      { k: 'Harmonic drive', v: '−72%' },
      { k: 'Solid-state LiDAR', v: '−91%' },
      { k: '6-DOF arm', v: '−78%' }
    ],
    chart: 'cost' },
  { n: '03', tag: 'DEMOGRAPHICS', title: 'The labor math finally inverted.',
    body: 'Working-age population is shrinking in every G7 economy plus China. Wage inflation in logistics and elder-care is structural, not cyclical. For the first time, robots are cheaper than the median worker on more than half of physical-labor tasks.',
    proof: [
      { k: 'Japan, 65+ share', v: '29.1%' },
      { k: 'US warehouse wage CAGR', v: '+6.2%' },
      { k: 'China working-age peak', v: '2011' }
    ],
    chart: 'demo' },
  { n: '04', tag: 'CAPITAL', title: 'Capital believes again, but selectively.',
    body: 'After the 2018-22 hardware winter, capital re-entered with sharper theses: foundation-model robotics, vertical AMRs, and humanoid platforms. Mega-rounds (>$200M) returned. Strategics — auto OEMs, hyperscalers, defense primes — are anchoring.',
    proof: [
      { k: '2024 robotics funding', v: '$6.4B' },
      { k: 'Median Series A', v: '$24M' },
      { k: 'Strategic-led rounds', v: '38%' }
    ],
    chart: 'cap' },
  { n: '05', tag: 'POLICY', title: 'Reshoring + sovereignty turned subsidies on.',
    body: 'CHIPS, IRA, EU Chips Act, India PLI, Japan METI: every major economy is paying for automated domestic manufacturing. Industrial robotics moved from CFO discretion to national-security capex. Defense robotics is a separate, larger budget line.',
    proof: [
      { k: 'India PLI, robotics-adj', v: '$24B' },
      { k: 'US DoD autonomy R&D', v: '$1.8B' },
      { k: 'EU AI Act exemptions', v: 'Industrial: yes' }
    ],
    chart: 'policy' },
];

function S02_WhyNow({ motion }) {
  const wrapRef = useR1(null);
  const trackRef = useR1(null);
  const [progress, setProgress] = useS1(0);

  useE1(() => {
    let raf = 0;
    const isMobile = () => window.matchMedia('(max-width: 820px)').matches;
    const tick = () => {
      raf = 0;
      const el = wrapRef.current; if (!el) return;
      if (isMobile()) {
        // CSS converts to vertical stack; don't drive transforms
        const track = trackRef.current;
        if (track) track.style.transform = '';
        setProgress(0);
        return;
      }
      const r = el.getBoundingClientRect();
      const vh = window.innerHeight;
      const t = Math.min(1, Math.max(0, -r.top / (r.height - vh)));
      setProgress(t);
      const track = trackRef.current;
      if (track) {
        const max = track.scrollWidth - window.innerWidth;
        track.style.transform = `translate3d(${-t * max}px, 0, 0)`;
      }
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(tick); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => { window.removeEventListener('scroll', onScroll); window.removeEventListener('resize', onScroll); raf && cancelAnimationFrame(raf); };
  }, []);

  return (
    <section id="why-now" data-section="02" data-screen-label="02 Why Now"
      ref={wrapRef}
      className="h-pin"
      style={{ height: `${TAILWINDS.length * 110}vh` }}>
      <div className="h-pin-stage" style={{ background: 'var(--paper)' }}>
        {/* Header overlay */}
        <div style={{ position: 'absolute', top: 24, left: 56, right: 56, zIndex: 5, display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <div className="row" style={{ gap: 18 }}>
            <span className="meta" style={{ color: 'var(--accent)' }}>§ 02 — Why Now</span>
            <span className="meta">Five structural tailwinds, ordered by causal weight</span>
          </div>
          <span className="meta">{Math.round(progress * 100)}%</span>
        </div>

        {/* progress strip */}
        <div style={{ position: 'absolute', top: 56, left: 56, right: 56, height: 2, background: 'var(--rule)', zIndex: 5 }}>
          <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${progress * 100}%`, background: 'var(--accent)' }}></div>
        </div>

        <div ref={trackRef} className="h-pin-track" style={{ width: `${TAILWINDS.length * 100}vw` }}>
          {TAILWINDS.map((t, i) => (
            <TailwindSlide key={i} t={t} motion={motion} idx={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function TailwindSlide({ t, motion, idx }) {
  return (
    <div className="h-slide" style={{ padding: '120px 80px 80px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr 380px', gap: 48, height: '100%' }}>
        {/* Number */}
        <div>
          <div className="serif tnum" style={{ fontSize: 132, lineHeight: 1, color: 'var(--ink-fade)' }}>{t.n}</div>
          <div className="meta" style={{ marginTop: 8 }}>Tailwind</div>
        </div>

        {/* Title + body */}
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', maxWidth: 720 }}>
          <div>
            <div className="kicker" style={{ marginBottom: 22 }}>{t.tag}</div>
            <h2 className="h1" style={{ marginBottom: 28 }}>{t.title}</h2>
            <p className="lead" style={{ maxWidth: 580 }}>{t.body}</p>
          </div>
          <div style={{ display: 'flex', gap: 24, paddingTop: 24, borderTop: '1px solid var(--rule)' }}>
            {t.proof.map((p, i) => (
              <div key={i} style={{ flex: 1 }}>
                <div className="meta" style={{ marginBottom: 6 }}>{p.k}</div>
                <div className="serif tnum" style={{ fontSize: 24, color: 'var(--accent)' }}>{p.v}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Visual */}
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <TailwindChart kind={t.chart} motion={motion} />
        </div>
      </div>
    </div>
  );
}

function TailwindChart({ kind, motion }) {
  if (kind === 'capability') {
    return (
      <div className="panel flush">
        <div className="panel-hd"><span className="ttl">Robot policy SOTA · success rate</span><span>2020 — 2026</span></div>
        <div style={{ padding: 18 }}>
          <AreaChart
            series={[
              { label: 'New tasks (zero-shot)', data: [4, 7, 11, 18, 31, 47, 62], color: 'var(--accent)', fill: true },
              { label: 'In-distribution', data: [22, 31, 44, 58, 71, 82, 89], color: 'var(--ink)' }
            ]}
            labels={['2020', '21', '22', '23', '24', '25', '26']}
            yFmt={(v) => `${Math.round(v)}%`}
            motion={motion}
            height={220}
          />
        </div>
      </div>
    );
  }
  if (kind === 'cost') {
    return (
      <div className="panel">
        <div className="meta" style={{ marginBottom: 12 }}>Component cost index · 2015 = 100</div>
        <BarChart
          data={[
            { label: '6-DOF arm', value: 22, color: 'var(--accent)', note: '−78%' },
            { label: 'Harmonic drive', value: 28, note: '−72%' },
            { label: 'IMU 9-axis', value: 14, note: '−86%' },
            { label: 'Solid-state LiDAR', value: 9, note: '−91%' },
            { label: 'BLDC actuator', value: 31, note: '−69%' },
            { label: 'Compute / TOPS', value: 6, note: '−94%' }
          ]}
          max={100} motion={motion}
          format={(v) => `${v}`}
        />
      </div>
    );
  }
  if (kind === 'demo') {
    return (
      <div className="panel flush">
        <div className="panel-hd"><span className="ttl">Working-age population</span><span>2000–2050 idx</span></div>
        <div style={{ padding: 18 }}>
          <AreaChart
            series={[
              { label: 'Japan', data: [100, 96, 92, 87, 82, 76, 70, 64, 59, 54, 50], color: 'var(--accent)' },
              { label: 'China', data: [86, 92, 98, 102, 100, 96, 91, 84, 76, 68, 60], color: 'var(--ink)' },
              { label: 'India', data: [60, 68, 76, 84, 91, 96, 99, 100, 99, 96, 92], color: 'var(--ink-mid)' }
            ]}
            labels={['00','05','10','15','20','25','30','35','40','45','50']}
            yFmt={(v) => v}
            motion={motion}
            height={220}
          />
        </div>
      </div>
    );
  }
  if (kind === 'cap') {
    return (
      <div className="panel flush">
        <div className="panel-hd"><span className="ttl">Robotics venture capital, USD B</span><span>2015–2025</span></div>
        <div style={{ padding: 18 }}>
          <StackedBars
            labels={['15','16','17','18','19','20','21','22','23','24','25']}
            series={[
              { label: 'Seed/A', data: [0.4,0.6,0.8,1.1,1.4,1.6,2.2,1.8,1.2,1.6,2.1], color: 'var(--accent)' },
              { label: 'B+', data: [0.8,1.2,1.6,2.8,3.4,2.6,5.6,4.2,2.4,3.8,4.6], color: 'var(--ink)' },
              { label: 'Strategic', data: [0.2,0.3,0.6,0.9,1.2,0.9,1.4,1.6,1.1,1.0,1.8], color: 'var(--ink-mid)' }
            ]}
            yFmt={(v) => `$${v.toFixed(1)}B`}
            motion={motion}
            height={220}
          />
        </div>
      </div>
    );
  }
  if (kind === 'policy') {
    return (
      <div className="panel">
        <div className="meta" style={{ marginBottom: 14 }}>Sovereign robotics-adjacent allocations</div>
        <BarChart
          data={[
            { label: 'US (CHIPS+IRA, robotics-eligible)', value: 52, color: 'var(--accent)', note: '$52B' },
            { label: 'EU Chips Act, automation', value: 43, note: '$43B' },
            { label: 'China Made-in-China 2025', value: 38, note: '$38B' },
            { label: 'India PLI, electronics+robotics', value: 24, note: '$24B' },
            { label: 'Japan METI moonshot', value: 12, note: '$12B' },
            { label: 'S. Korea K-Robotics', value: 8,  note: '$8B' }
          ]}
          max={60} motion={motion}
          format={() => ''}
        />
      </div>
    );
  }
  return null;
}

/* ============================================================
   SECTION 03 — CONSUMER ROBOTICS
   ============================================================ */
function S03_Consumer({ motion }) {
  return (
    <section id="consumer" data-section="03" data-screen-label="03 Consumer" className="section-pad">
      <div className="page">
        <SectionTag n="03" title="Consumer robotics — the long tail finally has product-market fit" source="iRobot S-1, Roborock IR, Anker filings, Goldman Sachs SUMMIT 2025"/>

        <div className="col-12">
          <Reveal style={{ gridColumn: '1 / span 7' }}>
            <h2 className="h2" style={{ marginBottom: 24 }}>
              Consumer robots stopped being a single category. They became a <em style={{ color: 'var(--accent)' }}>shelf</em>.
            </h2>
            <p className="lead">
              For 20 years, "consumer robotics" meant one product: the round vacuum. The last three years
              fragmented that category into a dozen workable archetypes — lawn, pool, window, cooking, pet,
              eldercare presence, garden. Each is solving a single physical chore for under <Gloss term="$2,000 ceiling" def="The empirical price ceiling above which consumer robot SKUs convert at less than 0.5% — derived from Roborock and Anker channel data.">a $2,000 ceiling</Gloss>.
            </p>
          </Reveal>
          <Reveal delay={200} style={{ gridColumn: '9 / span 4', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
            <Kpi label="Global consumer robot installed base" value={148} suffix="M" decimals={0} sub="2025 estimate · Statista + IFR composite" motion={motion}/>
            <Kpi label="Median consumer robot ASP" value={427} prefix="$" sub="down from $612 in 2022" motion={motion}/>
          </Reveal>
        </div>

        <div style={{ height: 80 }}></div>

        {/* Featured video + sidebar */}
        <div className="col-12">
          <Reveal style={{ gridColumn: '1 / span 8' }}>
            <Slot kind="video" label="iRobot Roomba demo · 2025 generation" source="YouTube" aspect="16/9"/>
          </Reveal>
          <Reveal delay={150} style={{ gridColumn: '9 / span 4' }}>
            <div className="panel">
              <div className="meta" style={{ marginBottom: 14 }}>Category leaders, by units 2024</div>
              <BarChart
                data={[
                  { label: 'Vacuum (Roborock)', value: 7.2, color: 'var(--accent)', note: '7.2M' },
                  { label: 'Vacuum (iRobot)',   value: 4.1, note: '4.1M' },
                  { label: 'Lawn (Husqvarna)',  value: 1.8, note: '1.8M' },
                  { label: 'Pool (Maytronics)', value: 1.2, note: '1.2M' },
                  { label: 'Window (Ecovacs)',  value: 0.9, note: '0.9M' }
                ]}
                max={8} motion={motion} format={() => ''}
              />
            </div>
          </Reveal>
        </div>

        <div style={{ height: 64 }}></div>

        {/* Three pillars */}
        <div className="col-3">
          {[
            { tag: 'Floor care', title: 'Vacuum has matured into a software business.',
              body: 'Roborock and Roomba ship every 6 months. The hardware is commodity; the moat is mapping, dirt detection, mop logic, and refill robotics. Margin shifted from the unit to the dock.',
              kpis: [['Median replacement cycle', '3.8 yrs'], ['Software-share of NPS', '64%']] },
            { tag: 'Outdoor', title: 'Lawn is the next $20B subcategory.',
              body: 'Husqvarna Automower, Mammotion, Eufy, Worx — wireless boundary, RTK GPS, and onboard vision dropped install time from a weekend to 18 minutes. Suburban TAM unblocked.',
              kpis: [['NA lawn TAM, 2027E', '$21B'], ['RTK SKU price floor', '$1,499']] },
            { tag: 'Companion', title: 'Eldercare presence is the dark horse.',
              body: 'Not the talking-face stuff. Stationary night-monitors, fall-detect cameras, medication dispensers with kinematic arms — boring, reimbursable, and growing 41% yoy in Japan.',
              kpis: [['Japan SKUs, 2025', '34'], ['Reimbursable units, JP', '~62%']] }
          ].map((p, i) => (
            <Reveal key={i} delay={i*100}>
              <div className="panel" style={{ height: '100%' }}>
                <Kicker>{p.tag}</Kicker>
                <h3 className="h3" style={{ margin: '14px 0 14px' }}>{p.title}</h3>
                <p style={{ color: 'var(--ink-mid)' }}>{p.body}</p>
                <hr className="hr-dash" style={{ margin: '20px 0' }}/>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {p.kpis.map((k, j) => (
                    <div key={j} style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--f-mono)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '.08em' }}>
                      <span className="dim">{k[0]}</span>
                      <span style={{ color: 'var(--accent)' }}>{k[1]}</span>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <div style={{ height: 64 }}></div>

        <Reveal>
          <Pull attrib="Internal Roborock OKR, leaked, Jan 2025">
            The robot that wins the home is not the one with the best motors. It is the one that
            requires the fewest decisions from the human.
          </Pull>
        </Reveal>

        <div style={{ height: 56 }}></div>

        <Reveal>
          <VideoReel
            title="Watch · consumer robotics in the wild"
            sub="6 videos · drop in your own"
            items={[
              { label: 'Roborock S8 MaxV — full dock teardown', source: 'YouTube · MKBHD' },
              { label: 'Mammotion LUBA RTK — boundary-free lawn', source: 'YouTube · DIY Garden' },
              { label: 'Maytronics Dolphin Liberty — pool bot', source: 'YouTube · PoolNerd' },
              { label: 'Ecovacs Winbot W2 — window cleaning', source: 'YouTube · Linus Tech Tips' },
              { label: 'Aibo 2025 refresh — emotional companion bot', source: 'YouTube · The Verge' },
              { label: 'iRobot Roomba 905 — mapping deep dive', source: 'YouTube · Vacuum Wars' }
            ]}/>
        </Reveal>

        <div style={{ height: 32 }}></div>

        <div className="col-2">
          <Reveal><Slot kind="article" label="‘Inside Roborock's mapping war’ — The Information" source="Article" aspect="4/3"/></Reveal>
          <Reveal delay={150}><Slot kind="article" label="‘Lawn is the new vacuum’ — Bloomberg, 2025" source="Article" aspect="4/3"/></Reveal>
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   SECTION 04 — MANUFACTURING / INDUSTRIAL
   ============================================================ */
function S04_Manufacturing({ motion }) {
  return (
    <section id="manufacturing" data-section="04" data-screen-label="04 Manufacturing" className="section-pad" style={{ background: 'var(--bg-alt)' }}>
      <div className="page">
        <SectionTag n="04" title="Manufacturing & industrial — the boring, profitable engine" source="IFR World Robotics 2024, MIR + AutoStore filings"/>

        <div className="col-12">
          <Reveal style={{ gridColumn: '1 / span 8' }}>
            <h2 className="h2" style={{ marginBottom: 28 }}>
              Industrial robotics is a <em>$78B</em> business growing at 11% annually — and almost nobody in tech-Twitter is paying attention to it.
            </h2>
          </Reveal>
        </div>

        <div style={{ height: 24 }}></div>

        {/* Dashboard grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: 16 }}>
          {/* Density map */}
          <Reveal style={{ gridColumn: 'span 7' }}>
            <div className="panel flush" style={{ height: '100%' }}>
              <div className="panel-hd"><span className="ttl">Robot density · units per 10,000 manufacturing workers</span><span>2024 · IFR</span></div>
              <div style={{ padding: 22 }}>
                <BarChart
                  data={[
                    { label: 'South Korea', value: 1012, color: 'var(--accent)', note: '#1' },
                    { label: 'Singapore',   value: 770, note: '#2' },
                    { label: 'China',       value: 470, note: '#3' },
                    { label: 'Germany',     value: 429, note: '#4' },
                    { label: 'Japan',       value: 419 },
                    { label: 'United States', value: 295 },
                    { label: 'Italy',       value: 219 },
                    { label: 'France',      value: 187 },
                    { label: 'India',       value: 7, color: 'var(--accent-deep)', note: 'opportunity' }
                  ]}
                  max={1100} motion={motion}
                  format={(v) => v}
                />
              </div>
            </div>
          </Reveal>

          {/* KPIs stack */}
          <div style={{ gridColumn: 'span 5', display: 'grid', gridTemplateRows: 'repeat(2, 1fr)', gap: 16 }}>
            <Reveal delay={100}>
              <div className="panel" style={{ height: '100%' }}>
                <div className="meta" style={{ marginBottom: 10 }}>Global installs · units</div>
                <AreaChart
                  series={[
                    { label: 'Industrial', data: [304, 254, 422, 517, 553, 590, 612], color: 'var(--accent)', fill: true },
                    { label: 'Service', data: [82, 96, 118, 158, 198, 246, 312], color: 'var(--ink)' }
                  ]}
                  labels={['18','19','20','21','22','23','24']}
                  yFmt={(v) => `${Math.round(v)}k`}
                  height={180} motion={motion}
                />
              </div>
            </Reveal>
            <Reveal delay={200}>
              <div className="panel" style={{ height: '100%' }}>
                <div className="meta" style={{ marginBottom: 14 }}>Top 5 industrial OEMs · market share '24</div>
                <Donut
                  data={[
                    { label: 'FANUC', value: 21, color: 'var(--accent)' },
                    { label: 'ABB', value: 16 },
                    { label: 'YASKAWA', value: 15 },
                    { label: 'KUKA (Midea)', value: 13 },
                    { label: 'Mitsubishi', value: 8 },
                    { label: 'Others', value: 27, color: 'var(--rule)' }
                  ]}
                  size={180} thick={22} motion={motion}
                />
              </div>
            </Reveal>
          </div>
        </div>

        <div style={{ height: 56 }}></div>

        {/* Two callouts: cobots vs traditional */}
        <div className="col-2">
          <Reveal>
            <div className="panel">
              <Kicker>The boring growth</Kicker>
              <h3 className="h3" style={{ margin: '14px 0 12px' }}>Cobots quietly ate the bottom of the market.</h3>
              <p style={{ color: 'var(--ink-mid)' }}>
                <Gloss term="Cobot" def="Collaborative robot — a force-limited arm safe to operate without a safety cage. Lower payload, lower speed, but trivial to deploy.">Collaborative arms</Gloss> went from 4% to 21% of new industrial installations in seven years. Universal Robots, Doosan, and Techman are the silent compounders.
              </p>
              <div style={{ marginTop: 18 }}>
                <Sparkline data={[4,5,7,10,13,16,18,21]} width={520} height={48} color="var(--accent)" fill motion={motion}/>
              </div>
              <div className="meta" style={{ marginTop: 8 }}>Cobot share of industrial installs · 2017–2024</div>
            </div>
          </Reveal>
          <Reveal delay={150}>
            <div className="panel">
              <Kicker>The big platform plays</Kicker>
              <h3 className="h3" style={{ margin: '14px 0 12px' }}>Warehouse automation became its own megacycle.</h3>
              <p style={{ color: 'var(--ink-mid)' }}>
                AutoStore IPO'd at $12B. Symbotic crossed $40B. Locus, Geek+, GreyOrange, AutoX — AMRs and goods-to-person are the largest revenue pool in robotics today. Amazon alone deploys ~750k.
              </p>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginTop: 18 }}>
                {[['Amazon AMRs', '750k'], ['AutoStore bins', '900k+'], ['US fulfillment $/order', '−18%']].map((k, i) => (
                  <div key={i}>
                    <div className="meta">{k[0]}</div>
                    <div className="serif tnum" style={{ fontSize: 26, color: 'var(--accent)' }}>{k[1]}</div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>

        <div style={{ height: 56 }}></div>
        <Reveal>
          <VideoReel
            title="Watch · industrial automation at scale"
            sub="6 videos · factories, warehouses, lights-out"
            items={[
              { label: 'FANUC lights-out factory — Yamanashi', source: 'YouTube · BBC Worklife' },
              { label: 'Symbotic warehouse — full system tour', source: 'YouTube · 60 Minutes' },
              { label: 'AutoStore — grid robotics walkthrough', source: 'YouTube · AutoStore' },
              { label: 'Amazon Sparrow + Sequoia at Houston FC', source: 'YouTube · CNBC' },
              { label: 'Universal Robots cobot welding cell', source: 'YouTube · UR official' },
              { label: 'KUKA + BMW assembly line, 2024', source: 'YouTube · BMW Group' }
            ]}/>
        </Reveal>
      </div>
    </section>
  );
}

/* ============================================================
   SECTION 05 — HUMANOIDS
   ============================================================ */
const HUMANOIDS = [
  { co: 'Figure', model: '02', country: 'US', height: 168, weight: 70, payload: 25, dof: 36, runtime: 5,  unitCost: 35000, status: 'Pilot · BMW' },
  { co: 'Tesla', model: 'Optimus Gen 3', country: 'US', height: 173, weight: 57, payload: 20, dof: 28, runtime: 8, unitCost: 22000, status: 'Internal pilot' },
  { co: 'Agility', model: 'Digit', country: 'US', height: 175, weight: 65, payload: 16, dof: 26, runtime: 4, unitCost: 30000, status: 'Commercial · GXO' },
  { co: 'Unitree', model: 'H1', country: 'CN', height: 180, weight: 47, payload: 30, dof: 27, runtime: 2,  unitCost: 16000, status: 'Shipping (research)' },
  { co: '1X', model: 'NEO', country: 'NO', height: 165, weight: 30, payload: 20, dof: 30, runtime: 4, unitCost: 20000, status: 'Beta · home' },
  { co: 'Apptronik', model: 'Apollo', country: 'US', height: 173, weight: 73, payload: 25, dof: 34, runtime: 4, unitCost: 50000, status: 'Pilot · Mercedes' },
  { co: 'Boston Dynamics', model: 'Atlas (electric)', country: 'US', height: 175, weight: 89, payload: 25, dof: 28, runtime: 1, unitCost: 0, status: 'R&D / Hyundai' },
  { co: 'Sanctuary AI', model: 'Phoenix v7', country: 'CA', height: 170, weight: 70, payload: 25, dof: 44, runtime: 3, unitCost: 0, status: 'Pilot' }
];

function S05_Humanoids({ motion }) {
  const [pick, setPick] = useS1(['Figure', 'Unitree']);
  const toggle = (co) => {
    if (pick.includes(co)) {
      if (pick.length > 1) setPick(pick.filter(c => c !== co));
    } else if (pick.length < 3) {
      setPick([...pick, co]);
    } else {
      setPick([pick[1], pick[2], co]);
    }
  };
  const chosen = HUMANOIDS.filter(h => pick.includes(h.co));

  return (
    <section id="humanoids" data-section="05" data-screen-label="05 Humanoids" className="section-pad">
      <div className="page">
        <SectionTag n="05" title="Humanoids — the noisiest, riskiest, possibly correct bet" source="Company filings, IEEE Spectrum, founder interviews"/>

        <div className="col-12">
          <Reveal style={{ gridColumn: '1 / span 7' }}>
            <h2 className="h2" style={{ marginBottom: 24 }}>
              The argument for humanoid form is one sentence: <em style={{ color: 'var(--accent)' }}>the world is already shaped for us.</em>
            </h2>
            <p className="lead">
              Door handles at 100cm. Stair risers at 17cm. Tool handles for a 5th-percentile-female grip.
              Every other form factor has to redesign the workspace; the humanoid pays a hardware tax to skip
              that integration cost. Whether that tax is worth it is the entire bet.
            </p>
          </Reveal>
          <Reveal delay={200} style={{ gridColumn: '9 / span 4' }}>
            <div className="panel">
              <div className="meta" style={{ marginBottom: 12 }}>Active humanoid programs, 2026</div>
              <div className="serif tnum" style={{ fontSize: 64, lineHeight: 1, marginBottom: 12 }}>
                <Counter value={47} motion={motion}/>
              </div>
              <div style={{ fontSize: 12, color: 'var(--ink-mid)' }}>up from 11 in 2022 · 23 are post-Series-A · 9 have shipped commercial pilots</div>
            </div>
          </Reveal>
        </div>

        <div style={{ height: 64 }}></div>

        {/* Comparator */}
        <Reveal>
          <div className="panel flush">
            <div className="panel-hd">
              <span className="ttl">Compare humanoid platforms · click to toggle (max 3)</span>
              <span>specs · public + estimated</span>
            </div>
            <div style={{ padding: 22 }}>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 24 }}>
                {HUMANOIDS.map(h => (
                  <button key={h.co} onClick={() => toggle(h.co)} className="chip"
                    style={{
                      cursor: 'pointer',
                      background: pick.includes(h.co) ? 'var(--accent)' : 'transparent',
                      color: pick.includes(h.co) ? '#fff' : 'var(--ink-mid)',
                      borderColor: pick.includes(h.co) ? 'var(--accent)' : 'var(--rule)'
                    }}>
                    {h.co} {h.model}
                  </button>
                ))}
              </div>
              <div className="h-compare-wrap">
                <HumanoidCompare units={chosen} motion={motion}/>
              </div>
            </div>
          </div>
        </Reveal>

        <div style={{ height: 56 }}></div>

        <Reveal>
          <VideoReel
            title="Watch · humanoid demos worth your time"
            sub="8 videos · curated from 2024–2026"
            items={[
              { label: 'Figure 02 — coffee-making, BMW pilot', source: 'YouTube · Figure' },
              { label: 'Unitree H1 — full-speed running outdoors', source: 'YouTube · Unitree' },
              { label: 'Tesla Optimus Gen 3 — Cybertruck delivery', source: 'YouTube · Tesla' },
              { label: 'Apptronik Apollo @ Mercedes-Benz plant', source: 'YouTube · Apptronik' },
              { label: '1X NEO — home demo, raw cut', source: 'YouTube · 1X Technologies' },
              { label: 'Boston Dynamics Atlas electric — first reveal', source: 'YouTube · Boston Dynamics' },
              { label: 'Sanctuary Phoenix — autonomous task suite', source: 'YouTube · Sanctuary AI' },
              { label: 'XPENG Iron — factory walkthrough', source: 'YouTube · XPENG' }
            ]}/>
        </Reveal>

        <div style={{ height: 56 }}></div>

        <Reveal>
          <Pull attrib="Brett Adcock · Figure · 2025">
            We are not building a robot. We are building a labor company that happens to use bipedal hardware.
          </Pull>
        </Reveal>

      </div>
    </section>
  );
}

function HumanoidCompare({ units, motion }) {
  const metrics = [
    { k: 'height',   l: 'Height',   fmt: (v) => `${v} cm`,    max: 200 },
    { k: 'weight',   l: 'Weight',   fmt: (v) => `${v} kg`,    max: 100 },
    { k: 'payload',  l: 'Payload',  fmt: (v) => `${v} kg`,    max: 35 },
    { k: 'dof',      l: 'DOF',      fmt: (v) => v,            max: 50 },
    { k: 'runtime',  l: 'Runtime',  fmt: (v) => `${v} h`,     max: 10 },
    { k: 'unitCost', l: 'Unit cost (est.)', fmt: (v) => v > 0 ? `$${(v/1000).toFixed(0)}k` : 'NDA', max: 60000 }
  ];
  const colors = ['var(--accent)', 'var(--ink)', 'var(--ink-mid)'];
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '160px 1fr', gap: 12, alignItems: 'center' }}>
      <div></div>
      <div style={{ display: 'flex', gap: 24 }}>
        {units.map((u, i) => (
          <div key={u.co} style={{ flex: 1, paddingLeft: 8 }}>
            <div className="meta" style={{ color: colors[i] }}>● {u.co}</div>
            <div className="serif" style={{ fontSize: 18, lineHeight: 1.2 }}>{u.model}</div>
            <div className="meta" style={{ marginTop: 4 }}>{u.country} · {u.status}</div>
          </div>
        ))}
      </div>
      {metrics.map(m => (
        <React.Fragment key={m.k}>
          <div className="meta" style={{ paddingTop: 14, borderTop: '1px solid var(--rule)' }}>{m.l}</div>
          <div style={{ display: 'flex', gap: 24, paddingTop: 14, borderTop: '1px solid var(--rule)' }}>
            {units.map((u, i) => (
              <div key={u.co} style={{ flex: 1 }}>
                <div className="tnum" style={{ fontSize: 19, fontFamily: 'var(--f-serif)', color: 'var(--ink)' }}>
                  {m.fmt(u[m.k])}
                </div>
                <div style={{ height: 4, background: 'var(--bg-deep)', marginTop: 6, position: 'relative', overflow: 'hidden' }}>
                  <div style={{
                    position: 'absolute', inset: 0,
                    width: `${Math.min(100, (u[m.k] / m.max) * 100)}%`,
                    background: colors[i],
                    transition: 'width .6s'
                  }}></div>
                </div>
              </div>
            ))}
          </div>
        </React.Fragment>
      ))}
    </div>
  );
}

/* ============================================================
   SECTION 06 — NON-HUMANOID FORM FACTORS
   ============================================================ */
const FORM_FACTORS = [
  { id: 'arm', name: 'Industrial arm', dof: '4–7',
    examples: ['FANUC M-2000', 'UR20', 'Kuka KR Quantec'],
    bestFor: 'Repetitive, fixed-position, high-payload tasks',
    weakness: 'Cannot move; one task per cell',
    units: '4.2M installed', cost: '$25k–$200k',
    icon: 'arm' },
  { id: 'cobot', name: 'Collaborative arm', dof: '6',
    examples: ['Universal UR5e', 'Doosan H-series', 'Techman TM12'],
    bestFor: 'Force-limited human-adjacent work',
    weakness: 'Lower payload, lower speed',
    units: '950k installed', cost: '$18k–$60k',
    icon: 'cobot' },
  { id: 'amr', name: 'Autonomous mobile robot', dof: '—',
    examples: ['Locus Origin', 'MiR 250', 'Geek+ P-series'],
    bestFor: 'Goods-to-person, intralogistics',
    weakness: 'Flat-floor only; mostly indoor',
    units: '~3M installed', cost: '$15k–$80k',
    icon: 'amr' },
  { id: 'agv', name: 'Auto guided vehicle', dof: '—',
    examples: ['Amazon Drive units', 'Symbotic', 'JBT'],
    bestFor: 'Heavy pallet movement on fixed routes',
    weakness: 'Inflexible without infrastructure',
    units: '~2M installed', cost: '$40k–$250k',
    icon: 'agv' },
  { id: 'quad', name: 'Quadruped', dof: '12–18',
    examples: ['Spot', 'Unitree Go2', 'ANYmal'],
    bestFor: 'Inspection, terrain that wheels fail on',
    weakness: 'Battery, payload, ROI thin',
    units: '~22k commercial', cost: '$3k–$75k',
    icon: 'quad' },
  { id: 'drone', name: 'Aerial drone', dof: '6',
    examples: ['Skydio', 'DJI Mavic 3 Enterprise', 'Wingcopter'],
    bestFor: 'Inspection, mapping, last-mile, defense',
    weakness: 'Weather, payload, airspace regs',
    units: '~7M commercial', cost: '$1k–$200k',
    icon: 'drone' },
  { id: 'underwater', name: 'Underwater (AUV/ROV)', dof: '6',
    examples: ['Blue Robotics', 'Saab Sabertooth', 'Anduril Dive'],
    bestFor: 'Subsea inspection, defense',
    weakness: 'Pressure, comms, salt corrosion',
    units: '~12k operational', cost: '$30k–$5M',
    icon: 'sub' },
  { id: 'micro', name: 'Soft / micro', dof: '—',
    examples: ['SoftRobotics gripper', 'Medical capsule bots'],
    bestFor: 'Delicate handling, surgical, agri',
    weakness: 'Niche, slow scale',
    units: '<5k commercial', cost: '$5k–$2M',
    icon: 'micro' }
];

function S06_NonHumanoid({ motion }) {
  const [hover, setHover] = useS1(null);
  return (
    <section id="form-factors" data-section="06" data-screen-label="06 Non-humanoid" className="section-pad" style={{ background: 'var(--bg-alt)' }}>
      <div className="page">
        <SectionTag n="06" title="Non-humanoid form factors — eight ways a robot can not be a person" source="IFR, Drone Industry Insights, Subsea UK"/>

        <div className="col-12">
          <Reveal style={{ gridColumn: '1 / span 8' }}>
            <h2 className="h2" style={{ marginBottom: 24 }}>
              The humanoid debate distracts from a quieter fact: <em>96% of operational robots in 2026 do not have legs.</em>
            </h2>
            <p className="lead">
              Every form factor is a different bet on what world the robot lives in. A drone bets the world has air,
              a quadruped bets it has stairs, an AMR bets it has flat floors and routine demand. Founders pick form
              before they pick problem; it should usually be the reverse.
            </p>
          </Reveal>
        </div>

        <div style={{ height: 56 }}></div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
          {FORM_FACTORS.map((f, i) => (
            <Reveal key={f.id} delay={i * 60}>
              <button
                onMouseEnter={() => setHover(f.id)}
                onMouseLeave={() => setHover(null)}
                style={{
                  all: 'unset', cursor: 'pointer',
                  background: 'var(--paper)',
                  border: '1px solid ' + (hover === f.id ? 'var(--accent)' : 'var(--rule)'),
                  padding: 20, height: '100%', minHeight: 280,
                  display: 'flex', flexDirection: 'column', gap: 12,
                  transition: 'border-color .2s, transform .2s',
                  transform: hover === f.id ? `translateY(-${4 * motion}px)` : 'none'
                }}>
                <FormIcon kind={f.icon} accent={hover === f.id} />
                <div className="meta">DOF · {f.dof}</div>
                <h4 className="h4" style={{ margin: 0 }}>{f.name}</h4>
                <p style={{ fontSize: 13, color: 'var(--ink-mid)', margin: 0, lineHeight: 1.45 }}>
                  <span style={{ color: 'var(--ink)' }}>Best for:</span> {f.bestFor}
                </p>
                <p style={{ fontSize: 12, color: 'var(--ink-low)', margin: 0, lineHeight: 1.45 }}>
                  <span style={{ color: 'var(--neg)' }}>Limit:</span> {f.weakness}
                </p>
                <div style={{ marginTop: 'auto', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', paddingTop: 12, borderTop: '1px dashed var(--rule)' }}>
                  <span className="meta">{f.units}</span>
                  <span className="meta" style={{ color: 'var(--accent)' }}>{f.cost}</span>
                </div>
              </button>
            </Reveal>
          ))}
        </div>

        <div style={{ height: 56 }}></div>

        <Reveal>
          <VideoReel
            title="Watch · the non-humanoid majority"
            sub="7 videos · every form factor"
            items={[
              { label: 'Boston Dynamics Spot — inspection compilation', source: 'YouTube · BD' },
              { label: 'Skydio X10 — autonomous infrastructure scan', source: 'YouTube · Skydio' },
              { label: 'ANYmal — offshore platform inspection', source: 'YouTube · ANYbotics' },
              { label: 'Locus Origin — fulfillment shift footage', source: 'YouTube · Locus Robotics' },
              { label: 'Carbon Robotics LaserWeeder — agri demo', source: 'YouTube · Carbon Robotics' },
              { label: 'Saronic Spyglass — marine swarm trials', source: 'YouTube · Saronic' },
              { label: 'Universal UR20 — heavy cobot welding', source: 'YouTube · Universal Robots' }
            ]}/>
        </Reveal>

        <div style={{ height: 32 }}></div>

        <div className="col-12">
          <Reveal style={{ gridColumn: '1 / span 7' }}>
            <div className="panel flush">
              <div className="panel-hd"><span className="ttl">Heard at IROS / RSS 2025 · selected papers</span><span>cherry-picked</span></div>
              <div style={{ padding: 18 }}>
                {[
                  ['Diffusion Policy 2 — multi-task long-horizon manipulation', 'Stanford, Toyota Research Inst.'],
                  ['Open X-Embodiment — cross-embodiment dataset, v2', 'DeepMind + 34 labs'],
                  ['ALOHA-2 — bimanual tele-op, $20k station', 'Stanford'],
                  ['Mobile ALOHA — wheelbase + arms, kitchen tasks', 'Stanford'],
                  ['π0-FAST — auto-regressive action tokenizer', 'Physical Intelligence']
                ].map((p, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: i < 4 ? '1px dashed var(--rule)' : 'none' }}>
                    <span>{p[0]}</span>
                    <span className="meta">{p[1]}</span>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
          <Reveal delay={150} style={{ gridColumn: '8 / span 5' }}>
            <div className="panel" style={{ height: '100%' }}>
              <Kicker>Form factor mix · 2030E</Kicker>
              <h3 className="h3" style={{ margin: '12px 0 14px' }}>Humanoids will be ~6% of new shipments — and ~38% of headlines.</h3>
              <div style={{ marginTop: 14, display: 'flex', justifyContent: 'center' }}>
                <Donut
                  data={[
                    { label: 'AMR/AGV', value: 38, color: 'var(--accent)' },
                    { label: 'Arms (incl. cobot)', value: 32, color: 'var(--ink)' },
                    { label: 'Drone', value: 14 },
                    { label: 'Humanoid', value: 6, color: 'var(--accent-deep)' },
                    { label: 'Quad / other', value: 10, color: 'var(--rule)' }
                  ]}
                  size={180} thick={22} motion={motion}
                />
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function FormIcon({ kind, accent }) {
  const c = accent ? 'var(--accent)' : 'var(--ink)';
  // Simple primitives — geometric only (no detailed robot drawings)
  const paths = {
    arm:   <g><rect x="14" y="42" width="32" height="6" fill={c}/><rect x="26" y="14" width="6" height="30" fill={c}/><circle cx="29" cy="14" r="4" fill={c}/><rect x="29" y="10" width="14" height="4" fill={c}/></g>,
    cobot: <g><rect x="14" y="42" width="32" height="6" fill={c}/><circle cx="29" cy="38" r="3" fill={c}/><rect x="26" y="20" width="6" height="18" fill={c}/><circle cx="29" cy="20" r="3" fill={c}/><rect x="29" y="16" width="10" height="6" fill={c}/></g>,
    amr:   <g><rect x="10" y="20" width="40" height="20" rx="3" fill={c}/><circle cx="18" cy="42" r="4" fill={c}/><circle cx="42" cy="42" r="4" fill={c}/><rect x="14" y="14" width="32" height="6" fill={c}/></g>,
    agv:   <g><rect x="8" y="18" width="44" height="22" fill={c}/><circle cx="16" cy="44" r="3" fill={c}/><circle cx="30" cy="44" r="3" fill={c}/><circle cx="44" cy="44" r="3" fill={c}/></g>,
    quad:  <g><rect x="14" y="22" width="32" height="10" fill={c}/><rect x="16" y="32" width="4" height="14" fill={c}/><rect x="40" y="32" width="4" height="14" fill={c}/><rect x="22" y="32" width="4" height="14" fill={c}/><rect x="34" y="32" width="4" height="14" fill={c}/></g>,
    drone: <g><circle cx="16" cy="20" r="6" fill={c}/><circle cx="44" cy="20" r="6" fill={c}/><circle cx="16" cy="40" r="6" fill={c}/><circle cx="44" cy="40" r="6" fill={c}/><rect x="22" y="26" width="16" height="8" fill={c}/></g>,
    sub:   <g><ellipse cx="30" cy="30" rx="22" ry="10" fill={c}/><rect x="48" y="26" width="6" height="8" fill={c}/><circle cx="22" cy="30" r="2" fill="var(--bg)"/></g>,
    micro: <g><circle cx="30" cy="30" r="14" fill="none" stroke={c} strokeWidth="3"/><circle cx="30" cy="30" r="4" fill={c}/><line x1="30" y1="10" x2="30" y2="18" stroke={c} strokeWidth="3"/><line x1="30" y1="42" x2="30" y2="50" stroke={c} strokeWidth="3"/></g>
  };
  return (
    <svg width="60" height="60" viewBox="0 0 60 60" style={{ transition: 'transform .3s', transform: accent ? 'scale(1.06)' : 'none' }}>
      {paths[kind] || null}
    </svg>
  );
}

Object.assign(window, {
  S01_Hook, S02_WhyNow, S03_Consumer, S04_Manufacturing, S05_Humanoids, S06_NonHumanoid
});
